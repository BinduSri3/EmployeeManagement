package com.cg.ems;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@ComponentScan(basePackages = {"com.cg.ems"})
@EntityScan("com.cg.ems.bean")
@EnableJpaRepositories("com.cg.ems.repository")
public class EmsMain {
	public static void main(String[] args) {
		SpringApplication.run(EmsMain.class, args);
	}


}
